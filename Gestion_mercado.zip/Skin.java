package proyecto;

public class Skin {

    double index;
    double calidad;
    double demanda;
    double oferta;
    int stattrak;
    int souvenir;
    int patron;
    double sticker;
    double drop;
    double estacion;
    double precio_base;

    double index2;
    double calidad2;
    double demanda2;
    double oferta2;
    int stattrak2;
    int souvenir2;
    int patron2;
    double sticker2;
    double drop2;
    double estacion2;
    double precio_base2;

    double index3;
    double calidad3;
    double demanda3;
    double oferta3;
    int stattrak3;
    int souvenir3;
    int patron3;
    double sticker3;
    double drop3;
    double estacion3;
    double precio_base3;

    public double precio_final1() {
        double precio_final = ((((((precio_base / (calidad + index + oferta + demanda + estacion) * stattrak) * souvenir) * patron) * sticker) * drop));
        return precio_final;
    }

    public double precio_final2() {
        double precio_final2 = ((((((precio_base2 / (calidad2 + index2 + oferta2 + demanda2 + estacion) * stattrak2) * souvenir2) * patron2) * sticker2) * drop2));
        return precio_final2;

    }
    public double precio_final3() {
        double precio_final3 = ((((((precio_base3 / (calidad3 + index3 + oferta3 + demanda3 + estacion) * stattrak3) * souvenir3) * patron3) * sticker3) * drop3));
        return precio_final3;
    }
}
