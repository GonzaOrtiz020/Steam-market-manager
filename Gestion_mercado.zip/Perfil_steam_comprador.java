
package proyecto;

public class Perfil_steam_comprador {
        
        public String nombre;
        public String usuario;
        public String contraseña;
        public String apellido;
}
