package proyecto;

import java.util.ArrayList;
import java.util.Scanner;

public class Gestion_mercado {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        Skin ultimo = new Skin();
        Perfil_steam datos = new Perfil_steam();
        Perfil_steam_comprador comprar = new Perfil_steam_comprador();

        String[] skins_disponibles;
        skins_disponibles = new String[3];

        System.out.print("Ingrese su nombre: ");
        datos.nombre = teclado.nextLine();

        System.out.print("Ingrese su apellido: ");
        datos.apellido = teclado.nextLine();

        System.out.print("Ingrese su nombre de usuario: ");
        datos.usuario = teclado.nextLine();

        System.out.println("Ingrese su contraseña: ");
        datos.contraseña = teclado.nextLine();

        System.out.println("Acceso aprobado");
        System.out.println("");

        System.out.println("Actualice su catálogo de skins(3 skins): ");

        System.out.println("Ingrese el nombre de la primera skin: ");
        teclado.next();
        skins_disponibles[0] = teclado.nextLine();

        System.out.println("Ingrese el nombre de la segunda skin: ");
        skins_disponibles[1] = teclado.nextLine();

        System.out.println("Ingrese el nombre de la tercera skin: ");
        skins_disponibles[2] = teclado.nextLine();

        System.out.println("Ingrese el precio base de la primera skin que desea vender (el valor es en dólares): ");
        ultimo.precio_base = teclado.nextDouble();

        System.out.println("Ingrese el precio base de la segunda skin que desea vender (el valor es en dólares): ");
        ultimo.precio_base2 = teclado.nextDouble();

        System.out.println("Ingrese el precio base de la tercera skin que desea vender (el valor es en dólares): ");
        ultimo.precio_base3 = teclado.nextDouble();

        System.out.println("");
        System.out.println("Ingrese el índice de desgaste de la primera skin: ");
        System.out.println("");
        System.out.print("Nuevo de fábrica(1) ");
        System.out.println("Casi nuevo(2)");
        System.out.print("Algo desgastado(3) ");
        System.out.println("Bastante desgastado(4)");
        System.out.println("Deplorable(5) ");
        System.out.println("");
        int indice = teclado.nextInt();
        switch (indice) {
            case 1:
                ultimo.index = 0.01;
                break;
            case 2:
                ultimo.index = 0.02;
                break;
            case 3:
                ultimo.index = 0.03;
                break;
            case 4:
                ultimo.index = 0.04;
                break;
            case 5:
                ultimo.index = 0.07;
                break;
            default:
                ultimo.index = 0;
                System.out.print("El valor de index es nulo, ya que el número escogido no se encuentra entre las opciones.");
                System.out.println("");
        }

        System.out.println("");
        System.out.println("Ingrese el índice de desgaste de la segunda skin: ");
        System.out.println("");
        System.out.print("Nuevo de fábrica(1) ");
        System.out.println("Casi nuevo(2)");
        System.out.print("Algo desgastado(3) ");
        System.out.println("Bastante desgastado(4)");
        System.out.println("Deplorable(5) ");
        System.out.println("");
        int indice2 = teclado.nextInt();
        switch (indice2) {
            case 1:
                ultimo.index2 = 0.01;
                break;
            case 2:
                ultimo.index2 = 0.02;
                break;
            case 3:
                ultimo.index2 = 0.03;
                break;
            case 4:
                ultimo.index2 = 0.04;
                break;
            case 5:
                ultimo.index2 = 0.07;
                break;
            default:
                ultimo.index2 = 0;
                System.out.print("El valor de index es nulo, ya que el número escogido no se encuentra entre las opciones.");
                System.out.println("");
        }

        System.out.println("");
        System.out.println("Ingrese el índice de desgaste de la tercera skin: ");
        System.out.println("");
        System.out.print("Nuevo de fábrica(1) ");
        System.out.println("Casi nuevo(2)");
        System.out.print("Algo desgastado(3) ");
        System.out.println("Bastante desgastado(4)");
        System.out.println("Deplorable(5) ");
        System.out.println("");
        int indice3 = teclado.nextInt();
        switch (indice3) {
            case 1:
                ultimo.index3 = 0.01;
                break;
            case 2:
                ultimo.index3 = 0.02;
                break;
            case 3:
                ultimo.index3 = 0.03;
                break;
            case 4:
                ultimo.index3 = 0.04;
                break;
            case 5:
                ultimo.index3 = 0.07;
                break;
            default:
                ultimo.index3 = 0;
                System.out.print("El valor de index es nulo, ya que el número escogido no se encuentra entre las opciones.");
                System.out.println("");
        }

        System.out.println("");
        System.out.println("En las siguientes opciones, escoja el número entre paréntesis correspondiente al atributo correcto: ");
        System.out.println("");
        System.out.println("Calidad de la skin: ");
        System.out.println("");
        System.out.print("Consumer (1) ");
        System.out.println("Industrial(2)");
        System.out.print("Mil-Spec(3) ");
        System.out.println("Restricted(4)");
        System.out.print("Classified(5) ");
        System.out.println("Covert(6)");
        System.out.print("Contraband(7) ");
        System.out.println("Extraordinary(8)");
        System.out.println("");
        int quality = teclado.nextInt();
        switch (quality) {
            case 1:
                ultimo.calidad = 0.65;
                break;
            case 2:
                ultimo.calidad = 0.6;
                break;
            case 3:
                ultimo.calidad = 0.55;
                break;
            case 4:
                ultimo.calidad = 0.5;
                break;
            case 5:
                ultimo.calidad = 0.3;
                break;
            case 6:
                ultimo.calidad = 0.2;
                break;
            case 7:
                ultimo.calidad = 0.02;
                break;
            case 8:
                ultimo.calidad = 0.1;
                break;
            default:
                ultimo.calidad = 0;
                System.out.print("El valor de calidad es nulo, ya que el número escogido no se encuentra entre las opciones.");
        }

        System.out.println("");
        System.out.println("Calidad de la skin: ");
        System.out.println("");
        System.out.print("Consumer (1) ");
        System.out.println("Industrial(2)");
        System.out.print("Mil-Spec(3) ");
        System.out.println("Restricted(4)");
        System.out.print("Classified(5) ");
        System.out.println("Covert(6)");
        System.out.print("Contraband(7) ");
        System.out.println("Extraordinary(8)");
        System.out.println("");
        int quality2 = teclado.nextInt();
        switch (quality2) {
            case 1:
                ultimo.calidad2 = 0.65;
                break;
            case 2:
                ultimo.calidad2 = 0.6;
                break;
            case 3:
                ultimo.calidad2 = 0.55;
                break;
            case 4:
                ultimo.calidad2 = 0.5;
                break;
            case 5:
                ultimo.calidad2 = 0.3;
                break;
            case 6:
                ultimo.calidad2 = 0.2;
                break;
            case 7:
                ultimo.calidad2 = 0.02;
                break;
            case 8:
                ultimo.calidad2 = 0.1;
                break;
            default:
                ultimo.calidad2 = 0;
                System.out.print("El valor de calidad es nulo, ya que el número escogido no se encuentra entre las opciones.");
        }

        System.out.println("");
        System.out.println("Calidad de la skin: ");
        System.out.println("");
        System.out.print("Consumer (1) ");
        System.out.println("Industrial(2)");
        System.out.print("Mil-Spec(3) ");
        System.out.println("Restricted(4)");
        System.out.print("Classified(5) ");
        System.out.println("Covert(6)");
        System.out.print("Contraband(7) ");
        System.out.println("Extraordinary(8)");
        System.out.println("");
        int quality3 = teclado.nextInt();
        switch (quality3) {
            case 1:
                ultimo.calidad3 = 0.65;
                break;
            case 2:
                ultimo.calidad3 = 0.6;
                break;
            case 3:
                ultimo.calidad3 = 0.55;
                break;
            case 4:
                ultimo.calidad3 = 0.5;
                break;
            case 5:
                ultimo.calidad3 = 0.3;
                break;
            case 6:
                ultimo.calidad3 = 0.2;
                break;
            case 7:
                ultimo.calidad3 = 0.02;
                break;
            case 8:
                ultimo.calidad3 = 0.1;
                break;
            default:
                ultimo.calidad3 = 0;
                System.out.print("El valor de calidad es nulo, ya que el número escogido no se encuentra entre las opciones.");
        }

        System.out.println();
        System.out.print("Demanda de la primera skin: alta(1) baja(2): ");
        int demand = teclado.nextInt();
        switch (demand) {
            case 1:
                ultimo.demanda = 0;
                break;
            case 2:
                ultimo.demanda = 0.01;
                break;
            default:
                ultimo.demanda = 0;
                System.out.print("El valor de demanda es nulo, ya que el número escogido no se encuentra entre las opciones.");
        }

        System.out.println();
        System.out.print("Demanda de la segunda skin: alta(1) baja(2): ");
        int demand2 = teclado.nextInt();
        switch (demand2) {
            case 1:
                ultimo.demanda2 = 0;
                break;
            case 2:
                ultimo.demanda2 = 0.01;
                break;
            default:
                ultimo.demanda2 = 0;
                System.out.print("El valor de demanda es nulo, ya que el número escogido no se encuentra entre las opciones.");
        }

        System.out.println();
        System.out.print("Demanda de la tercera skin: alta(1) baja(2): ");
        int demand3 = teclado.nextInt();
        switch (demand3) {
            case 1:
                ultimo.demanda3 = 0;
                break;
            case 2:
                ultimo.demanda3 = 0.01;
                break;
            default:
                ultimo.demanda3 = 0;
                System.out.print("El valor de demanda es nulo, ya que el número escogido no se encuentra entre las opciones.");
        }

        System.out.print("Oferta de la primera skin: alta(1) baja(2): ");
        int offer = teclado.nextInt();
        switch (offer) {
            case 1:
                ultimo.oferta = 0.02;
                break;
            case 2:
                ultimo.oferta = -0.02;
                break;
            default:
                ultimo.oferta = 0;
                System.out.print("El valor de oferta es nulo, ya que el número escogido no se encuentra entre las opciones.");
        }

        System.out.print("Oferta de la segunda skin: alta(1) baja(2): ");
        int offer2 = teclado.nextInt();
        switch (offer2) {
            case 1:
                ultimo.oferta2 = 0.02;
                break;
            case 2:
                ultimo.oferta2 = -0.02;
                break;
            default:
                ultimo.oferta2 = 0;
                System.out.print("El valor de oferta es nulo, ya que el número escogido no se encuentra entre las opciones.");
        }

        System.out.print("Oferta de la tercera skin: alta(1) baja(2): ");
        int offer3 = teclado.nextInt();
        switch (offer3) {
            case 1:
                ultimo.oferta3 = 0.02;
                break;
            case 2:
                ultimo.oferta3 = -0.02;
                break;
            default:
                ultimo.oferta3 = 0;
                System.out.print("El valor de oferta es nulo, ya que el número escogido no se encuentra entre las opciones.");
        }

        System.out.print("La primera skin tiene StatTrak(1) No tiene StatTrak(2): ");
        int stat = teclado.nextInt();
        switch (stat) {
            case 1:
                ultimo.stattrak = 2;
                break;
            case 2:
                ultimo.stattrak = 1;
                break;
            default:
                ultimo.stattrak = 1;
                System.out.print("El valor de stattrak es nulo, ya que el número escogido no se encuentra entre las opciones.");
        }

        System.out.print("La segunda skin tiene StatTrak(1) No tiene StatTrak(2): ");
        int stat2 = teclado.nextInt();
        switch (stat2) {
            case 1:
                ultimo.stattrak2 = 2;
                break;
            case 2:
                ultimo.stattrak2 = 1;
                break;
            default:
                ultimo.stattrak2 = 1;
                System.out.print("El valor de stattrak es nulo, ya que el número escogido no se encuentra entre las opciones.");
        }

        System.out.print("La tercera skin tiene StatTrak(1) No tiene StatTrak(2): ");
        int stat3 = teclado.nextInt();
        switch (stat3) {
            case 1:
                ultimo.stattrak3 = 2;
                break;
            case 2:
                ultimo.stattrak3 = 1;
                break;
            default:
                ultimo.stattrak3 = 1;
                System.out.print("El valor de stattrak es nulo, ya que el número escogido no se encuentra entre las opciones.");
        }

        System.out.print("La primera skin es Souvenir(1) No es Souvenir(2): ");
        int souv = teclado.nextInt();
        switch (souv) {
            case 1:
                ultimo.souvenir = 3;
                break;
            case 2:
                ultimo.souvenir = 1;
                break;
            default:
                ultimo.souvenir = 1;
                System.out.print("El valor de souvenir es nulo, ya que el número escogido no se encuentra entre las opciones.");
        }

        System.out.print("La segunda skin es Souvenir(1) No es Souvenir(2): ");
        int souv2 = teclado.nextInt();
        switch (souv2) {
            case 1:
                ultimo.souvenir2 = 3;
                break;
            case 2:
                ultimo.souvenir2 = 1;
                break;
            default:
                ultimo.souvenir2 = 1;
                System.out.print("El valor de souvenir es nulo, ya que el número escogido no se encuentra entre las opciones.");
        }

        System.out.print("La tercera skin es Souvenir(1) No es Souvenir(2): ");
        int souv3 = teclado.nextInt();
        switch (souv3) {
            case 1:
                ultimo.souvenir3 = 3;
                break;
            case 2:
                ultimo.souvenir3 = 1;
                break;
            default:
                ultimo.souvenir3 = 1;
                System.out.print("El valor de souvenir es nulo, ya que el número escogido no se encuentra entre las opciones.");
        }

        System.out.print("La primera skin tiene patrón especial(1) No tiene patrón especial(2): ");
        int pattern = teclado.nextInt();
        switch (pattern) {
            case 1:
                ultimo.patron = 3;
                break;
            case 2:
                ultimo.patron = 1;
                break;
            default:
                ultimo.patron = 1;
                System.out.print("El valor de patron es nulo, ya que el número escogido no se encuentra entre las opciones.");
        }

        System.out.print("La segunda skin tiene patrón especial(1) No tiene patrón especial(2): ");
        int pattern2 = teclado.nextInt();
        switch (pattern2) {
            case 1:
                ultimo.patron2 = 3;
                break;
            case 2:
                ultimo.patron2 = 1;
                break;
            default:
                ultimo.patron2 = 1;
                System.out.print("El valor de patron es nulo, ya que el número escogido no se encuentra entre las opciones.");
        }

        System.out.print("La tercera skin tiene patrón especial(1) No tiene patrón especial(2): ");
        int pattern3 = teclado.nextInt();
        switch (pattern3) {
            case 1:
                ultimo.patron3 = 3;
                break;
            case 2:
                ultimo.patron3 = 1;
                break;
            default:
                ultimo.patron3 = 1;
                System.out.print("El valor de patron es nulo, ya que el número escogido no se encuentra entre las opciones.");
        }

        System.out.print("La primera tiene un sticker raro(1) No tiene un sticker raro(2): ");
        int stick = teclado.nextInt();
        switch (stick) {
            case 1:
                ultimo.sticker = 1.5;
                break;
            case 2:
                ultimo.sticker = 1;
                break;
            default:
                ultimo.sticker = 1;
                System.out.print("El valor de sticker es nulo, ya que el número escogido no se encuentra entre las opciones.");
        }

        System.out.print("La segunda tiene un sticker raro(1) No tiene un sticker raro(2): ");
        int stick2 = teclado.nextInt();
        switch (stick2) {
            case 1:
                ultimo.sticker2 = 1.5;
                break;
            case 2:
                ultimo.sticker2 = 1;
                break;
            default:
                ultimo.sticker2 = 1;
                System.out.print("El valor de sticker es nulo, ya que el número escogido no se encuentra entre las opciones.");
        }

        System.out.print("La tercera tiene un sticker raro(1) No tiene un sticker raro(2): ");
        int stick3 = teclado.nextInt();
        switch (stick3) {
            case 1:
                ultimo.sticker3 = 1.5;
                break;
            case 2:
                ultimo.sticker3 = 1;
                break;
            default:
                ultimo.sticker3 = 1;
                System.out.print("El valor de sticker es nulo, ya que el número escogido no se encuentra entre las opciones.");
        }

        System.out.print("La primera skin se encuentra en la drop pool(1) No se encuentra en la drop pool(2) - "
                + "Consulte en: https://www.csgodatabase.com/cases/ : ");
        int pool = teclado.nextInt();
        switch (pool) {
            case 1:
                ultimo.drop = 1;
                break;
            case 2:
                ultimo.drop = 1.15;
                break;
            default:
                ultimo.drop = 1;
                System.out.print("El valor de drop es nulo, ya que el número escogido no se encuentra entre las opciones.");
        }

        System.out.print("La segunda skin se encuentra en la drop pool(1) No se encuentra en la drop pool(2) - "
                + "Consulte en: https://www.csgodatabase.com/cases/ : ");
        int pool2 = teclado.nextInt();
        switch (pool2) {
            case 1:
                ultimo.drop2 = 1;
                break;
            case 2:
                ultimo.drop2 = 1.15;
                break;
            default:
                ultimo.drop2 = 1;
                System.out.print("El valor de drop es nulo, ya que el número escogido no se encuentra entre las opciones.");
        }

        System.out.print("La tercera skin se encuentra en la drop pool(1) No se encuentra en la drop pool(2) - "
                + "Consulte en: https://www.csgodatabase.com/cases/ : ");
        int pool3 = teclado.nextInt();
        switch (pool3) {
            case 1:
                ultimo.drop3 = 1;
                break;
            case 2:
                ultimo.drop3 = 1.15;
                break;
            default:
                ultimo.drop3 = 1;
                System.out.print("El valor de drop es nulo, ya que el número escogido no se encuentra entre las opciones.");
        }

        System.out.print("Es verano(1) No es verano(2): ");
        int summer = teclado.nextInt();
        switch (summer) {
            case 1:
                ultimo.estacion = 0.01;
                break;
            case 2:
                ultimo.estacion = 0;
                break;
            default:
                ultimo.estacion = 0;
                System.out.print("El valor de estación es nulo, ya que el número escogido no se encuentra entre las opciones.");
        }

        System.out.println("El precio de la primera skin es de: " + ultimo.precio_final1());
        System.out.println("El precio de la segunda skin es de: " + ultimo.precio_final2());
        System.out.println("El precio de la tercera skin es de: " + ultimo.precio_final3());
        System.out.println("");

        teclado.nextLine();
        System.out.print("Señor/a comprador, ingrese su nombre por favor: ");
        comprar.nombre = teclado.nextLine();

        System.out.print("Ingrese su apellido, por favor: ");
        comprar.apellido = teclado.nextLine();

        System.out.print("Ingrese su usuario, por favor: ");
        comprar.usuario = teclado.nextLine();

        System.out.print("Ingrese su contraseña, por favor: ");
        comprar.contraseña = teclado.nextLine();

        System.out.println("A continuación, le mostraremos el catálogo disponible para su compra, junto a sus precios: ");
        System.out.println("");
        System.out.println(skins_disponibles[0] + ultimo.precio_final1());
        System.out.println(skins_disponibles[1] + ultimo.precio_final2());
        System.out.println(skins_disponibles[2] + ultimo.precio_final2());

        System.out.println("Escoja la skin que desea comprar: ");
        System.out.println("(1)" + "," + skins_disponibles[0]);
        System.out.println("(2)" + "," + skins_disponibles[1]);
        System.out.println("(3)" + "," + skins_disponibles[2]);
        int cual = teclado.nextInt();

        if (cual == 1) {
            System.out.println("Ha comprado correctamente la skin: " + skins_disponibles[0]);
        }

        if (cual == 2) {
            System.out.println("Ha comprado correctamente la skin: " + skins_disponibles[1]);
        }

        if (cual == 3) {
            System.out.println("Ha comprado correctamente la skin: " + skins_disponibles[2]);
        }
            System.out.print("Gracias por utilizar nuestro software, hasta la próxima " + comprar.usuario);
    }

}
